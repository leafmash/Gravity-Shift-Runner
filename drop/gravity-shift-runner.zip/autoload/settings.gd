extends Node

signal changed

const QUALITY_NAMES := ["Low", "Medium", "High"]

func set_music_volume(value: float) -> void:
    SaveManager.music_volume = clampf(value, 0.0, 1.0)
    changed.emit()

func set_sfx_volume(value: float) -> void:
    SaveManager.sfx_volume = clampf(value, 0.0, 1.0)
    changed.emit()

func set_vibration(enabled: bool) -> void:
    SaveManager.vibration = enabled
    persist()
    changed.emit()

func set_quality(level: int) -> void:
    SaveManager.quality = clampi(level, 0, 2)
    persist()
    changed.emit()

func quality_name() -> String:
    return QUALITY_NAMES[SaveManager.quality]

func persist() -> void:
    SaveManager.save_data()

func vibrate(milliseconds: int) -> void:
    if SaveManager.vibration:
        Input.vibrate_handheld(milliseconds)

extends Node

const Config = preload("res://scripts/config.gd")

signal state_changed(new_state)
signal score_changed(value)
signal combo_changed(combo_count, multiplier_value)
signal orbs_changed(value)
signal tier_changed(new_tier)
signal run_ended(final_score, best_score, orbs, new_best)

enum State { MENU, PLAYING, PAUSED, GAME_OVER }

var state: State = State.MENU
var score := 0.0
var combo := 0
var multiplier := 1
var run_orbs := 0
var distance := 0.0
var speed := Config.START_SPEED
var tier := 0
var run_time := 0.0
var combo_timer := 0.0
var slow_time_left := 0.0
var magnet_left := 0.0
var invulnerable_left := 0.0
var shield := false
var revive_used := false
var tutorial_active := false

func _set_state(value: State) -> void:
    state = value
    state_changed.emit(value)

func start_run() -> void:
    score = 0.0
    combo = 0
    multiplier = 1
    run_orbs = 0
    run_time = 0.0
    speed = Config.START_SPEED
    tier = 0
    combo_timer = 0.0
    slow_time_left = 0.0
    magnet_left = 0.0
    invulnerable_left = 0.0
    shield = false
    revive_used = false
    tutorial_active = not SaveManager.tutorial_seen
    _set_state(State.PLAYING)
    score_changed.emit(0)
    combo_changed.emit(0, 1)
    orbs_changed.emit(0)
    tier_changed.emit(0)

func finish_tutorial() -> void:
    tutorial_active = false
    run_time = 0.0
    SaveManager.tutorial_seen = true
    SaveManager.save_data()

func pause() -> void:
    if state == State.PLAYING:
        _set_state(State.PAUSED)

func resume() -> void:
    if state == State.PAUSED:
        _set_state(State.PLAYING)

func go_menu() -> void:
    SaveManager.save_data()
    _set_state(State.MENU)

func end_run() -> void:
    if state != State.PLAYING:
        return
    _set_state(State.GAME_OVER)
    var final_score := int(score)
    var new_best := final_score > SaveManager.high_score
    if new_best:
        SaveManager.high_score = final_score
    SaveManager.save_data()
    run_ended.emit(final_score, SaveManager.high_score, run_orbs, new_best)

func can_revive() -> bool:
    return not revive_used and SaveManager.total_orbs >= Config.REVIVE_COST

func revive() -> bool:
    if state != State.GAME_OVER or not can_revive():
        return false
    SaveManager.total_orbs -= Config.REVIVE_COST
    SaveManager.save_data()
    revive_used = true
    invulnerable_left = 2.5
    shield = false
    _set_state(State.PLAYING)
    return true

func time_factor() -> float:
    if tutorial_active:
        return Config.TUTORIAL_FACTOR
    if slow_time_left > 0.0:
        return Config.SLOW_FACTOR
    return 1.0

func speed_ratio() -> float:
    return clampf((speed - Config.START_SPEED) / (Config.MAX_SPEED - Config.START_SPEED), 0.0, 1.0)

func tick(delta: float) -> void:
    if state != State.PLAYING:
        return
    run_time += delta
    if tutorial_active:
        speed = Config.START_SPEED
    else:
        speed = minf(Config.MAX_SPEED, Config.START_SPEED + run_time * Config.SPEED_RAMP)
    var step := speed * time_factor() * delta
    distance += step
    if not tutorial_active:
        _add_score(step * multiplier)
    slow_time_left = maxf(0.0, slow_time_left - delta)
    magnet_left = maxf(0.0, magnet_left - delta)
    invulnerable_left = maxf(0.0, invulnerable_left - delta)
    if combo > 0:
        combo_timer -= delta
        if combo_timer <= 0.0:
            _reset_combo()

func collect_orb() -> void:
    run_orbs += 1
    SaveManager.total_orbs += 1
    orbs_changed.emit(run_orbs)
    _register_combo_event()
    _add_score(Config.ORB_SCORE * multiplier)

func register_close_call() -> void:
    _register_combo_event()
    _add_score(Config.CLOSE_CALL_SCORE * multiplier)

func activate_powerup(kind: int) -> void:
    match kind:
        Config.Obstacle.SHIELD:
            shield = true
        Config.Obstacle.SLOW:
            slow_time_left = Config.SLOW_DURATION
        Config.Obstacle.MAGNET:
            magnet_left = Config.MAGNET_DURATION

func absorb_hit() -> bool:
    if invulnerable_left > 0.0:
        return true
    if shield:
        shield = false
        invulnerable_left = 1.0
        _reset_combo()
        return true
    return false

func _register_combo_event() -> void:
    combo += 1
    multiplier = mini(1 + int(combo / 4.0), Config.MAX_MULTIPLIER)
    combo_timer = Config.COMBO_WINDOW
    combo_changed.emit(combo, multiplier)

func _reset_combo() -> void:
    combo = 0
    multiplier = 1
    combo_changed.emit(0, 1)

func _add_score(amount: float) -> void:
    score += amount
    score_changed.emit(int(score))
    var new_tier := int(score / Config.TIER_SCORE)
    if new_tier > tier:
        tier = new_tier
        tier_changed.emit(tier)

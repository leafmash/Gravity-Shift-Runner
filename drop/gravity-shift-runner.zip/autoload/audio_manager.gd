extends Node

const SAMPLE_RATE := 22050
const MUSIC_BPM := 140.0
const MUSIC_STEPS := 16
const VOICE_COUNT := 8
const BASS_NOTES := [55.0, 43.65, 65.41, 49.0]
const CHORDS := [
    [220.0, 261.63, 329.63],
    [174.61, 220.0, 261.63],
    [261.63, 329.63, 392.0],
    [196.0, 246.94, 293.66],
]

var sfx_library := {}
var voices: Array = []
var voice_cursor := 0
var bass_player: AudioStreamPlayer
var lead_player: AudioStreamPlayer

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _create_buses()
    _build_sfx()
    _build_music()
    Settings.changed.connect(_apply_volumes)
    _apply_volumes()

func play_sfx(sfx_name: String, pitch: float = 1.0) -> void:
    if not sfx_library.has(sfx_name):
        return
    var voice: AudioStreamPlayer = voices[voice_cursor]
    voice_cursor = (voice_cursor + 1) % voices.size()
    voice.stream = sfx_library[sfx_name]
    voice.pitch_scale = pitch
    voice.play()

func set_intensity(value: float) -> void:
    var level := clampf(value, 0.0, 1.0)
    lead_player.volume_db = lerpf(-30.0, -7.0, level)
    var pitch := 1.0 + level * 0.1
    bass_player.pitch_scale = pitch
    lead_player.pitch_scale = pitch

func _create_buses() -> void:
    for bus_name in ["Music", "SFX"]:
        if AudioServer.get_bus_index(bus_name) == -1:
            AudioServer.add_bus()
            var index := AudioServer.bus_count - 1
            AudioServer.set_bus_name(index, bus_name)
            AudioServer.set_bus_send(index, "Master")

func _apply_volumes() -> void:
    _set_bus("Music", SaveManager.music_volume)
    _set_bus("SFX", SaveManager.sfx_volume)

func _set_bus(bus_name: String, linear: float) -> void:
    var index := AudioServer.get_bus_index(bus_name)
    AudioServer.set_bus_mute(index, linear <= 0.001)
    AudioServer.set_bus_volume_db(index, linear_to_db(maxf(linear, 0.001)))

func _wave(kind: int, phase: float) -> float:
    var cycle := fposmod(phase, 1.0)
    match kind:
        1:
            return 0.6 if cycle < 0.5 else -0.6
        2:
            return (cycle * 2.0 - 1.0) * 0.7
        3:
            return (absf(cycle * 4.0 - 2.0) - 1.0) * 0.9
    return sin(cycle * TAU)

func _tone(duration: float, freq_start: float, freq_end: float, kind: int, gain: float, noise_mix: float) -> PackedFloat32Array:
    var count := int(duration * SAMPLE_RATE)
    var out := PackedFloat32Array()
    out.resize(count)
    var phase := 0.0
    for i in count:
        var t := float(i) / count
        phase += lerpf(freq_start, freq_end, t) / SAMPLE_RATE
        var envelope := pow(1.0 - t, 2.0) * minf(1.0, t * 30.0)
        var sample := _wave(kind, phase)
        if noise_mix > 0.0:
            sample = sample * (1.0 - noise_mix) + randf_range(-1.0, 1.0) * noise_mix
        out[i] = sample * envelope * gain
    return out

func _whoosh(duration: float) -> PackedFloat32Array:
    var count := int(duration * SAMPLE_RATE)
    var out := PackedFloat32Array()
    out.resize(count)
    var low := 0.0
    for i in count:
        var t := float(i) / count
        var cutoff := lerpf(0.02, 0.35, sin(t * PI))
        low += (randf_range(-1.0, 1.0) - low) * cutoff
        out[i] = low * sin(t * PI) * 1.8
    return out

func _mix_into(target: PackedFloat32Array, source: PackedFloat32Array, offset: int) -> void:
    var limit := mini(source.size(), target.size() - offset)
    for i in limit:
        target[offset + i] += source[i]

func _make_stream(samples: PackedFloat32Array, looped: bool) -> AudioStreamWAV:
    var bytes := PackedByteArray()
    bytes.resize(samples.size() * 2)
    for i in samples.size():
        bytes.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32767.0))
    var stream := AudioStreamWAV.new()
    stream.format = AudioStreamWAV.FORMAT_16_BITS
    stream.mix_rate = SAMPLE_RATE
    stream.stereo = false
    stream.data = bytes
    if looped:
        stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
        stream.loop_begin = 0
        stream.loop_end = samples.size()
    return stream

func _build_sfx() -> void:
    for i in VOICE_COUNT:
        var voice := AudioStreamPlayer.new()
        voice.bus = "SFX"
        add_child(voice)
        voices.append(voice)
    sfx_library["shift"] = _make_stream(_whoosh(0.32), false)
    sfx_library["jump"] = _make_stream(_tone(0.22, 280.0, 720.0, 0, 0.6, 0.0), false)
    sfx_library["crash"] = _make_stream(_tone(0.8, 220.0, 35.0, 2, 0.7, 0.55), false)
    sfx_library["click"] = _make_stream(_tone(0.07, 1200.0, 700.0, 1, 0.4, 0.0), false)
    sfx_library["shield_break"] = _make_stream(_tone(0.35, 900.0, 200.0, 1, 0.5, 0.5), false)
    sfx_library["close_call"] = _make_stream(_tone(0.15, 600.0, 1200.0, 3, 0.5, 0.0), false)
    var chime := PackedFloat32Array()
    chime.resize(int(0.4 * SAMPLE_RATE))
    _mix_into(chime, _tone(0.25, 988.0, 988.0, 0, 0.5, 0.0), 0)
    _mix_into(chime, _tone(0.3, 1319.0, 1319.0, 0, 0.5, 0.0), int(0.08 * SAMPLE_RATE))
    sfx_library["orb"] = _make_stream(chime, false)
    var arpeggio := PackedFloat32Array()
    arpeggio.resize(int(0.6 * SAMPLE_RATE))
    var notes := [523.0, 659.0, 784.0, 1047.0]
    for i in notes.size():
        var note: float = notes[i]
        _mix_into(arpeggio, _tone(0.2, note, note, 3, 0.5, 0.0), int(i * 0.07 * SAMPLE_RATE))
    sfx_library["powerup"] = _make_stream(arpeggio, false)

func _build_music() -> void:
    var step_seconds := 60.0 / MUSIC_BPM / 2.0
    var step_samples := int(step_seconds * SAMPLE_RATE)
    var total := step_samples * MUSIC_STEPS
    var bass := PackedFloat32Array()
    bass.resize(total)
    var lead := PackedFloat32Array()
    lead.resize(total)
    for step in MUSIC_STEPS:
        var chord_index := int(step / 4.0)
        var start := step * step_samples
        var root: float = BASS_NOTES[chord_index]
        var bass_freq := root if step % 2 == 0 else root * 2.0
        _mix_into(bass, _tone(step_seconds * 0.9, bass_freq, bass_freq, 2, 0.35, 0.0), start)
        if step % 4 == 0:
            _mix_into(bass, _tone(0.18, 140.0, 38.0, 0, 0.9, 0.0), start)
        var chord: Array = CHORDS[chord_index]
        var arp_freq: float = chord[step % 3]
        if step % 8 >= 4:
            arp_freq *= 2.0
        _mix_into(lead, _tone(step_seconds * 0.8, arp_freq, arp_freq, 1, 0.22, 0.0), start)
        if step % 2 == 1:
            _mix_into(lead, _tone(0.05, 1.0, 1.0, 0, 0.2, 1.0), start)
    bass_player = AudioStreamPlayer.new()
    bass_player.stream = _make_stream(bass, true)
    bass_player.bus = "Music"
    bass_player.volume_db = -6.0
    add_child(bass_player)
    lead_player = AudioStreamPlayer.new()
    lead_player.stream = _make_stream(lead, true)
    lead_player.bus = "Music"
    lead_player.volume_db = -30.0
    add_child(lead_player)
    bass_player.play()
    lead_player.play()

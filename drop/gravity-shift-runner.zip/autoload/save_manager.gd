extends Node

const SAVE_PATH := "user://gravity_shift_runner.cfg"

var high_score := 0
var total_orbs := 0
var tutorial_seen := false
var music_volume := 0.7
var sfx_volume := 0.9
var vibration := true
var quality := 1

func _ready() -> void:
    load_data()

func load_data() -> void:
    var config := ConfigFile.new()
    if config.load(SAVE_PATH) != OK:
        return
    high_score = int(config.get_value("progress", "high_score", 0))
    total_orbs = int(config.get_value("progress", "total_orbs", 0))
    tutorial_seen = bool(config.get_value("progress", "tutorial_seen", false))
    music_volume = float(config.get_value("settings", "music_volume", 0.7))
    sfx_volume = float(config.get_value("settings", "sfx_volume", 0.9))
    vibration = bool(config.get_value("settings", "vibration", true))
    quality = clampi(int(config.get_value("settings", "quality", 1)), 0, 2)

func save_data() -> void:
    var config := ConfigFile.new()
    config.set_value("progress", "high_score", high_score)
    config.set_value("progress", "total_orbs", total_orbs)
    config.set_value("progress", "tutorial_seen", tutorial_seen)
    config.set_value("settings", "music_volume", music_volume)
    config.set_value("settings", "sfx_volume", sfx_volume)
    config.set_value("settings", "vibration", vibration)
    config.set_value("settings", "quality", quality)
    config.save(SAVE_PATH)

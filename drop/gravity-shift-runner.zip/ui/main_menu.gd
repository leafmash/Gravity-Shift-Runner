extends Control

signal play_pressed
signal settings_pressed

const UiKit = preload("res://ui/ui_kit.gd")

var title_label: Label
var highscore_panel: Control
var best_value: Label
var orbs_value: Label

func _ready() -> void:
    UiKit.fill(self)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    var margin := UiKit.safe_container(get_viewport())
    UiKit.fill(margin)
    add_child(margin)
    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 26)
    margin.add_child(column)
    column.add_child(UiKit.spacer(true))
    title_label = UiKit.label("GRAVITY SHIFT", 78, UiKit.ACCENT)
    column.add_child(title_label)
    column.add_child(UiKit.label("RUNNER", 130, UiKit.GOLD))
    column.add_child(UiKit.spacer(true))
    var play := UiKit.button("PLAY", UiKit.ACCENT, Vector2(480.0, 120.0), 52)
    play.pressed.connect(play_pressed.emit)
    column.add_child(play)
    var score_button := UiKit.button("HIGH SCORE", UiKit.GOLD)
    score_button.pressed.connect(_show_highscore)
    column.add_child(score_button)
    var settings_button := UiKit.button("SETTINGS", UiKit.ACCENT)
    settings_button.pressed.connect(settings_pressed.emit)
    column.add_child(settings_button)
    column.add_child(UiKit.spacer(true, 40.0))
    _build_highscore_panel()
    _animate_title()

func _build_highscore_panel() -> void:
    highscore_panel = Control.new()
    UiKit.fill(highscore_panel)
    highscore_panel.visible = false
    add_child(highscore_panel)
    var dim := ColorRect.new()
    dim.color = Color(0.0, 0.0, 0.0, 0.6)
    UiKit.fill(dim)
    highscore_panel.add_child(dim)
    var center := CenterContainer.new()
    UiKit.fill(center)
    highscore_panel.add_child(center)
    var panel := UiKit.panel()
    panel.custom_minimum_size = Vector2(520.0, 0.0)
    center.add_child(panel)
    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 18)
    panel.add_child(column)
    column.add_child(UiKit.label("BEST SCORE", 40, UiKit.GOLD))
    best_value = UiKit.label("0", 96)
    column.add_child(best_value)
    column.add_child(UiKit.label("TOTAL ORBS", 40, UiKit.ACCENT))
    orbs_value = UiKit.label("0", 72)
    column.add_child(orbs_value)
    var close := UiKit.button("CLOSE", UiKit.ACCENT, Vector2(360.0, 90.0))
    close.pressed.connect(_hide_highscore)
    column.add_child(close)

func _show_highscore() -> void:
    best_value.text = str(SaveManager.high_score)
    orbs_value.text = str(SaveManager.total_orbs)
    UiKit.fade_in(highscore_panel)

func _hide_highscore() -> void:
    highscore_panel.visible = false

func _animate_title() -> void:
    var tween := create_tween().set_loops()
    tween.tween_property(title_label, "modulate", Color(0.7, 0.9, 1.0), 1.2).set_trans(Tween.TRANS_SINE)
    tween.tween_property(title_label, "modulate", Color(1.0, 1.0, 1.0), 1.2).set_trans(Tween.TRANS_SINE)

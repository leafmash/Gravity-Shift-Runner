extends RefCounted

const ACCENT := Color(0.1, 0.9, 1.0)
const WARNING := Color(1.0, 0.3, 0.45)
const GOLD := Color(1.0, 0.85, 0.2)
const TEXT := Color(0.92, 0.97, 1.0)
const PANEL_BG := Color(0.02, 0.03, 0.09, 0.88)

static func style_box(background: Color, border: Color, radius: int = 20, border_width: int = 3) -> StyleBoxFlat:
    var box := StyleBoxFlat.new()
    box.bg_color = background
    box.border_color = border
    box.set_border_width_all(border_width)
    box.set_corner_radius_all(radius)
    box.content_margin_left = 28.0
    box.content_margin_right = 28.0
    box.content_margin_top = 16.0
    box.content_margin_bottom = 16.0
    return box

static func fill(control: Control) -> void:
    control.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

static func button(text: String, color: Color = ACCENT, minimum: Vector2 = Vector2(440.0, 100.0), font_size: int = 40) -> Button:
    var control := Button.new()
    control.text = text
    control.custom_minimum_size = minimum
    control.focus_mode = Control.FOCUS_NONE
    control.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    control.add_theme_font_size_override("font_size", font_size)
    control.add_theme_color_override("font_color", TEXT)
    control.add_theme_color_override("font_pressed_color", TEXT)
    control.add_theme_color_override("font_hover_color", TEXT)
    control.add_theme_color_override("font_disabled_color", Color(0.5, 0.52, 0.58))
    control.add_theme_stylebox_override("normal", style_box(color.darkened(0.82), color))
    control.add_theme_stylebox_override("hover", style_box(color.darkened(0.72), color.lightened(0.2)))
    control.add_theme_stylebox_override("pressed", style_box(color.darkened(0.55), color.lightened(0.35)))
    control.add_theme_stylebox_override("disabled", style_box(Color(0.08, 0.08, 0.1), Color(0.3, 0.3, 0.35)))
    control.resized.connect(func() -> void: control.pivot_offset = control.size / 2.0)
    control.button_down.connect(func() -> void: _scale_to(control, 0.93))
    control.button_up.connect(func() -> void: _scale_to(control, 1.0))
    control.pressed.connect(_play_click)
    return control

static func label(text: String, size: int = 36, color: Color = TEXT) -> Label:
    var control := Label.new()
    control.text = text
    control.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    control.mouse_filter = Control.MOUSE_FILTER_IGNORE
    control.add_theme_font_size_override("font_size", size)
    control.add_theme_color_override("font_color", color)
    control.add_theme_color_override("font_outline_color", Color(0.0, 0.0, 0.0, 0.8))
    control.add_theme_constant_override("outline_size", maxi(2, int(size / 12.0)))
    return control

static func spacer(expand: bool = true, height: float = 0.0) -> Control:
    var control := Control.new()
    control.mouse_filter = Control.MOUSE_FILTER_IGNORE
    control.custom_minimum_size = Vector2(0.0, height)
    if expand:
        control.size_flags_vertical = Control.SIZE_EXPAND_FILL
    return control

static func panel() -> PanelContainer:
    var control := PanelContainer.new()
    control.add_theme_stylebox_override("panel", style_box(PANEL_BG, ACCENT, 28, 3))
    return control

static func fade_in(control: Control, duration: float = 0.25) -> void:
    control.visible = true
    control.modulate.a = 0.0
    var tween := control.create_tween()
    tween.tween_property(control, "modulate:a", 1.0, duration)

static func safe_margins(viewport: Viewport) -> Dictionary:
    var window_size := Vector2(DisplayServer.window_get_size())
    var visible_size := viewport.get_visible_rect().size
    var safe := Rect2(DisplayServer.get_display_safe_area())
    var margins := {"left": 24.0, "top": 24.0, "right": 24.0, "bottom": 24.0}
    if window_size.x <= 0.0 or window_size.y <= 0.0 or safe.size.x <= 0.0:
        return margins
    var scale_x := visible_size.x / window_size.x
    var scale_y := visible_size.y / window_size.y
    margins["left"] = clampf(safe.position.x * scale_x, 24.0, 160.0)
    margins["top"] = clampf(safe.position.y * scale_y, 24.0, 160.0)
    margins["right"] = clampf((window_size.x - safe.end.x) * scale_x, 24.0, 160.0)
    margins["bottom"] = clampf((window_size.y - safe.end.y) * scale_y, 24.0, 160.0)
    return margins

static func safe_container(viewport: Viewport) -> MarginContainer:
    var margins := safe_margins(viewport)
    var container := MarginContainer.new()
    container.mouse_filter = Control.MOUSE_FILTER_IGNORE
    container.add_theme_constant_override("margin_left", int(margins["left"]))
    container.add_theme_constant_override("margin_top", int(margins["top"]))
    container.add_theme_constant_override("margin_right", int(margins["right"]))
    container.add_theme_constant_override("margin_bottom", int(margins["bottom"]))
    return container

static func circle_texture(diameter: int, color: Color) -> ImageTexture:
    var image := Image.create(diameter, diameter, false, Image.FORMAT_RGBA8)
    var center := Vector2(diameter, diameter) / 2.0
    var radius := diameter / 2.0
    for x in diameter:
        for y in diameter:
            var distance := Vector2(x + 0.5, y + 0.5).distance_to(center)
            image.set_pixel(x, y, Color(color.r, color.g, color.b, clampf(radius - distance, 0.0, 1.0)))
    return ImageTexture.create_from_image(image)

static func slider(initial: float) -> HSlider:
    var control := HSlider.new()
    control.min_value = 0.0
    control.max_value = 1.0
    control.step = 0.01
    control.value = initial
    control.focus_mode = Control.FOCUS_NONE
    control.custom_minimum_size = Vector2(440.0, 56.0)
    var track := style_box(Color(0.08, 0.1, 0.18), ACCENT.darkened(0.5), 8, 2)
    track.content_margin_top = 6.0
    track.content_margin_bottom = 6.0
    var filled := style_box(ACCENT.darkened(0.2), ACCENT, 8, 0)
    filled.content_margin_top = 6.0
    filled.content_margin_bottom = 6.0
    control.add_theme_stylebox_override("slider", track)
    control.add_theme_stylebox_override("grabber_area", filled)
    control.add_theme_stylebox_override("grabber_area_highlight", filled)
    var knob := circle_texture(44, ACCENT)
    control.add_theme_icon_override("grabber", knob)
    control.add_theme_icon_override("grabber_highlight", knob)
    control.add_theme_icon_override("grabber_disabled", knob)
    return control

static func _scale_to(control: Control, target: float) -> void:
    var tween := control.create_tween()
    tween.tween_property(control, "scale", Vector2(target, target), 0.1).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

static func _play_click() -> void:
    AudioManager.play_sfx("click")
    Settings.vibrate(8)

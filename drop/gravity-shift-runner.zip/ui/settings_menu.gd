extends Control

signal closed

const UiKit = preload("res://ui/ui_kit.gd")

var vibration_button: Button
var quality_button: Button

func _ready() -> void:
    UiKit.fill(self)
    var dim := ColorRect.new()
    dim.color = Color(0.0, 0.0, 0.02, 0.78)
    UiKit.fill(dim)
    add_child(dim)
    var margin := UiKit.safe_container(get_viewport())
    UiKit.fill(margin)
    add_child(margin)
    var center := CenterContainer.new()
    margin.add_child(center)
    var panel := UiKit.panel()
    panel.custom_minimum_size = Vector2(560.0, 0.0)
    center.add_child(panel)
    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 14)
    panel.add_child(column)
    column.add_child(UiKit.label("SETTINGS", 72, UiKit.ACCENT))
    column.add_child(UiKit.label("MUSIC", 34))
    var music_slider := UiKit.slider(SaveManager.music_volume)
    music_slider.value_changed.connect(Settings.set_music_volume)
    music_slider.drag_ended.connect(_on_slider_released)
    column.add_child(music_slider)
    column.add_child(UiKit.label("SFX", 34))
    var sfx_slider := UiKit.slider(SaveManager.sfx_volume)
    sfx_slider.value_changed.connect(Settings.set_sfx_volume)
    sfx_slider.drag_ended.connect(_on_sfx_released)
    column.add_child(sfx_slider)
    vibration_button = UiKit.button(_vibration_text(), UiKit.ACCENT, Vector2(480.0, 90.0), 34)
    vibration_button.pressed.connect(_on_vibration_pressed)
    column.add_child(vibration_button)
    quality_button = UiKit.button(_quality_text(), UiKit.GOLD, Vector2(480.0, 90.0), 34)
    quality_button.pressed.connect(_on_quality_pressed)
    column.add_child(quality_button)
    var back := UiKit.button("BACK", UiKit.WARNING, Vector2(480.0, 90.0))
    back.pressed.connect(closed.emit)
    column.add_child(back)

func _vibration_text() -> String:
    return "VIBRATION: %s" % ("ON" if SaveManager.vibration else "OFF")

func _quality_text() -> String:
    return "GRAPHICS: %s" % Settings.quality_name().to_upper()

func _on_slider_released(_changed: bool) -> void:
    Settings.persist()

func _on_sfx_released(_changed: bool) -> void:
    Settings.persist()
    AudioManager.play_sfx("orb")

func _on_vibration_pressed() -> void:
    Settings.set_vibration(not SaveManager.vibration)
    vibration_button.text = _vibration_text()

func _on_quality_pressed() -> void:
    Settings.set_quality((SaveManager.quality + 1) % 3)
    quality_button.text = _quality_text()

extends Control

signal finished

const UiKit = preload("res://ui/ui_kit.gd")
const TutorialIcon = preload("res://ui/tutorial_icon.gd")

const STEPS := [
    {"title": "TAP LEFT SIDE", "hint": "Rotate gravity counter-clockwise"},
    {"title": "TAP RIGHT SIDE", "hint": "Rotate gravity clockwise"},
    {"title": "SWIPE UP", "hint": "Jump over blocks and gaps"},
]

var step_index := 0
var active := false
var title_label: Label
var hint_label: Label
var icon

func _ready() -> void:
    UiKit.fill(self)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    icon = TutorialIcon.new()
    UiKit.fill(icon)
    icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(icon)
    var margin := UiKit.safe_container(get_viewport())
    UiKit.fill(margin)
    add_child(margin)
    var column := VBoxContainer.new()
    column.mouse_filter = Control.MOUSE_FILTER_IGNORE
    margin.add_child(column)
    column.add_child(UiKit.spacer(true, 260.0))
    var panel := UiKit.panel()
    panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    column.add_child(panel)
    var texts := VBoxContainer.new()
    texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.add_child(texts)
    title_label = UiKit.label("", 52, UiKit.GOLD)
    texts.add_child(title_label)
    hint_label = UiKit.label("", 32)
    texts.add_child(hint_label)
    column.add_child(UiKit.spacer(true, 500.0))

func begin() -> void:
    step_index = 0
    active = true
    _apply_step()
    UiKit.fade_in(self)

func on_shift(direction: int) -> void:
    if not active:
        return
    if step_index == 0 and direction > 0:
        _advance()
    elif step_index == 1 and direction < 0:
        _advance()

func on_jump() -> void:
    if active and step_index == 2:
        _advance()

func _apply_step() -> void:
    var step: Dictionary = STEPS[step_index]
    title_label.text = step["title"]
    hint_label.text = step["hint"]
    icon.mode = step_index
    icon.elapsed = 0.0

func _advance() -> void:
    AudioManager.play_sfx("powerup")
    step_index += 1
    if step_index >= STEPS.size():
        active = false
        var tween := create_tween()
        tween.tween_property(self, "modulate:a", 0.0, 0.3)
        tween.tween_callback(_complete)
        return
    _apply_step()

func _complete() -> void:
    visible = false
    finished.emit()

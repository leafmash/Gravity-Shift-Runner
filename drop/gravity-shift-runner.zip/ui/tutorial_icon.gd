extends Control

var mode := 0
var elapsed := 0.0

func _process(delta: float) -> void:
    if not is_visible_in_tree():
        return
    elapsed += delta
    queue_redraw()

func _draw() -> void:
    var pulse := 0.5 + 0.5 * sin(elapsed * 5.0)
    var color := Color(0.3, 0.95, 1.0, 0.9)
    match mode:
        0:
            _draw_tap(Vector2(size.x * 0.25, size.y * 0.66), pulse, color, -1.0)
        1:
            _draw_tap(Vector2(size.x * 0.75, size.y * 0.66), pulse, color, 1.0)
        2:
            _draw_swipe(color)

func _draw_tap(center: Vector2, pulse: float, color: Color, direction: float) -> void:
    draw_circle(center, 44.0, Color(color, 0.35))
    draw_arc(center, 44.0 + 30.0 * pulse, 0.0, TAU, 40, Color(color, 0.8 * (1.0 - pulse)), 4.0)
    for index in 2:
        var tip := center + Vector2(direction * (80.0 + index * 34.0 + pulse * 10.0), 0.0)
        draw_line(tip, tip + Vector2(-direction * 18.0, -18.0), color, 6.0)
        draw_line(tip, tip + Vector2(-direction * 18.0, 18.0), color, 6.0)

func _draw_swipe(color: Color) -> void:
    var progress := fposmod(elapsed * 0.9, 1.0)
    var eased := 1.0 - pow(1.0 - progress, 2.0)
    var center := Vector2(size.x * 0.5, lerpf(size.y * 0.74, size.y * 0.5, eased))
    var alpha := 1.0 - smoothstep(0.7, 1.0, progress)
    draw_circle(center, 44.0, Color(color, 0.4 * alpha))
    var tip := center + Vector2(0.0, -70.0)
    draw_line(tip, tip + Vector2(-20.0, 20.0), Color(color, alpha), 6.0)
    draw_line(tip, tip + Vector2(20.0, 20.0), Color(color, alpha), 6.0)

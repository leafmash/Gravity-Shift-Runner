extends Control

signal pause_pressed

const UiKit = preload("res://ui/ui_kit.gd")

var score_label: Label
var combo_label: Label
var orbs_label: Label
var timers_label: Label

func _ready() -> void:
    UiKit.fill(self)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    var margin := UiKit.safe_container(get_viewport())
    UiKit.fill(margin)
    add_child(margin)
    var top := HBoxContainer.new()
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    top.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
    margin.add_child(top)
    var left := VBoxContainer.new()
    left.mouse_filter = Control.MOUSE_FILTER_IGNORE
    left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(left)
    score_label = _left_label("0", 72, UiKit.TEXT)
    left.add_child(score_label)
    combo_label = _left_label("", 40, UiKit.GOLD)
    left.add_child(combo_label)
    timers_label = _left_label("", 30, UiKit.ACCENT)
    left.add_child(timers_label)
    var right := VBoxContainer.new()
    right.mouse_filter = Control.MOUSE_FILTER_IGNORE
    top.add_child(right)
    var pause_button := UiKit.button("II", UiKit.ACCENT, Vector2(96.0, 96.0), 40)
    pause_button.size_flags_horizontal = Control.SIZE_SHRINK_END
    pause_button.pressed.connect(pause_pressed.emit)
    right.add_child(pause_button)
    orbs_label = UiKit.label("ORBS 0", 34, UiKit.GOLD)
    orbs_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    right.add_child(orbs_label)
    GameState.score_changed.connect(_on_score_changed)
    GameState.combo_changed.connect(_on_combo_changed)
    GameState.orbs_changed.connect(_on_orbs_changed)

func _process(_delta: float) -> void:
    if not visible:
        return
    var parts := PackedStringArray()
    if GameState.shield:
        parts.append("SHIELD")
    if GameState.slow_time_left > 0.0:
        parts.append("SLOW %.1f" % GameState.slow_time_left)
    if GameState.magnet_left > 0.0:
        parts.append("MAGNET %.1f" % GameState.magnet_left)
    timers_label.text = "\n".join(parts)

func _left_label(text: String, size: int, color: Color) -> Label:
    var control := UiKit.label(text, size, color)
    control.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
    return control

func _on_score_changed(value: int) -> void:
    score_label.text = str(value)

func _on_orbs_changed(value: int) -> void:
    orbs_label.text = "ORBS %d" % value

func _on_combo_changed(_combo: int, multiplier: int) -> void:
    if multiplier <= 1:
        combo_label.text = ""
        return
    combo_label.text = "COMBO x%d" % multiplier
    combo_label.pivot_offset = Vector2(0.0, combo_label.size.y * 0.5)
    combo_label.scale = Vector2(1.35, 1.35)
    var tween := create_tween()
    tween.tween_property(combo_label, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

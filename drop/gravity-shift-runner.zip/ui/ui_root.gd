extends CanvasLayer

signal play_requested
signal pause_requested
signal resume_requested
signal restart_requested
signal home_requested
signal revive_requested
signal tutorial_finished

const UiKit = preload("res://ui/ui_kit.gd")
const MainMenu = preload("res://ui/main_menu.gd")
const Hud = preload("res://ui/hud.gd")
const PauseMenu = preload("res://ui/pause_menu.gd")
const GameOverMenu = preload("res://ui/game_over_menu.gd")
const SettingsMenu = preload("res://ui/settings_menu.gd")
const TutorialOverlay = preload("res://ui/tutorial_overlay.gd")

var main_menu
var hud
var pause_menu
var game_over_menu
var settings_menu
var tutorial

func _ready() -> void:
    layer = 10
    process_mode = Node.PROCESS_MODE_ALWAYS
    main_menu = MainMenu.new()
    hud = Hud.new()
    tutorial = TutorialOverlay.new()
    pause_menu = PauseMenu.new()
    game_over_menu = GameOverMenu.new()
    settings_menu = SettingsMenu.new()
    for screen in [main_menu, hud, tutorial, pause_menu, game_over_menu, settings_menu]:
        screen.visible = false
        add_child(screen)
    main_menu.play_pressed.connect(play_requested.emit)
    main_menu.settings_pressed.connect(_open_settings)
    settings_menu.closed.connect(_close_settings)
    hud.pause_pressed.connect(pause_requested.emit)
    pause_menu.resume_pressed.connect(resume_requested.emit)
    pause_menu.restart_pressed.connect(restart_requested.emit)
    pause_menu.home_pressed.connect(home_requested.emit)
    game_over_menu.revive_pressed.connect(revive_requested.emit)
    game_over_menu.restart_pressed.connect(restart_requested.emit)
    game_over_menu.home_pressed.connect(home_requested.emit)
    tutorial.finished.connect(tutorial_finished.emit)

func show_main_menu() -> void:
    _hide_all()
    UiKit.fade_in(main_menu)

func show_hud() -> void:
    _hide_all()
    UiKit.fade_in(hud, 0.2)

func show_pause() -> void:
    UiKit.fade_in(pause_menu, 0.2)

func hide_pause() -> void:
    pause_menu.visible = false

func show_game_over(final_score: int, best: int, orbs: int, can_revive: bool, cost: int, new_best: bool) -> void:
    _hide_all()
    game_over_menu.populate(final_score, best, orbs, can_revive, cost, new_best)
    UiKit.fade_in(game_over_menu)

func begin_tutorial() -> void:
    tutorial.begin()

func _hide_all() -> void:
    for screen in [main_menu, hud, tutorial, pause_menu, game_over_menu, settings_menu]:
        screen.visible = false

func _open_settings() -> void:
    main_menu.visible = false
    UiKit.fade_in(settings_menu)

func _close_settings() -> void:
    settings_menu.visible = false
    UiKit.fade_in(main_menu)

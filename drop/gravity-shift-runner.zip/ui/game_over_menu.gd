extends Control

signal revive_pressed
signal restart_pressed
signal home_pressed

const UiKit = preload("res://ui/ui_kit.gd")

var title_label: Label
var score_label: Label
var best_label: Label
var orbs_label: Label
var revive_button: Button

func _ready() -> void:
    UiKit.fill(self)
    var dim := ColorRect.new()
    dim.color = Color(0.0, 0.0, 0.02, 0.72)
    UiKit.fill(dim)
    add_child(dim)
    var margin := UiKit.safe_container(get_viewport())
    UiKit.fill(margin)
    add_child(margin)
    var center := CenterContainer.new()
    margin.add_child(center)
    var panel := UiKit.panel()
    panel.custom_minimum_size = Vector2(560.0, 0.0)
    center.add_child(panel)
    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 18)
    panel.add_child(column)
    title_label = UiKit.label("CRASHED", 76, UiKit.WARNING)
    column.add_child(title_label)
    column.add_child(UiKit.label("SCORE", 34, UiKit.ACCENT))
    score_label = UiKit.label("0", 110)
    column.add_child(score_label)
    best_label = UiKit.label("BEST 0", 40, UiKit.GOLD)
    column.add_child(best_label)
    orbs_label = UiKit.label("ORBS +0", 40, UiKit.ACCENT)
    column.add_child(orbs_label)
    revive_button = UiKit.button("REVIVE", UiKit.GOLD, Vector2(480.0, 96.0), 34)
    revive_button.pressed.connect(revive_pressed.emit)
    column.add_child(revive_button)
    var restart := UiKit.button("RESTART", UiKit.ACCENT, Vector2(480.0, 96.0))
    restart.pressed.connect(restart_pressed.emit)
    column.add_child(restart)
    var home := UiKit.button("HOME", UiKit.WARNING, Vector2(480.0, 96.0))
    home.pressed.connect(home_pressed.emit)
    column.add_child(home)

func populate(final_score: int, best: int, orbs: int, can_revive: bool, cost: int, new_best: bool) -> void:
    title_label.text = "NEW BEST!" if new_best else "CRASHED"
    title_label.add_theme_color_override("font_color", UiKit.GOLD if new_best else UiKit.WARNING)
    score_label.text = str(final_score)
    best_label.text = "BEST %d" % best
    orbs_label.text = "ORBS +%d" % orbs
    revive_button.text = "REVIVE (%d ORBS)" % cost
    revive_button.disabled = not can_revive

extends Control

signal resume_pressed
signal restart_pressed
signal home_pressed

const UiKit = preload("res://ui/ui_kit.gd")

func _ready() -> void:
    UiKit.fill(self)
    var dim := ColorRect.new()
    dim.color = Color(0.0, 0.0, 0.02, 0.7)
    UiKit.fill(dim)
    add_child(dim)
    var margin := UiKit.safe_container(get_viewport())
    UiKit.fill(margin)
    add_child(margin)
    var center := CenterContainer.new()
    margin.add_child(center)
    var panel := UiKit.panel()
    panel.custom_minimum_size = Vector2(520.0, 0.0)
    center.add_child(panel)
    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 22)
    panel.add_child(column)
    column.add_child(UiKit.label("PAUSED", 84, UiKit.ACCENT))
    var resume := UiKit.button("RESUME", UiKit.ACCENT)
    resume.pressed.connect(resume_pressed.emit)
    column.add_child(resume)
    var restart := UiKit.button("RESTART", UiKit.GOLD)
    restart.pressed.connect(restart_pressed.emit)
    column.add_child(restart)
    var home := UiKit.button("HOME", UiKit.WARNING)
    home.pressed.connect(home_pressed.emit)
    column.add_child(home)

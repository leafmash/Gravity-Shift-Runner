extends Node3D

signal crash_finished

const Config = preload("res://scripts/config.gd")
const Materials = preload("res://scripts/visuals/materials.gd")
const TunnelBuilder = preload("res://scripts/tunnel/tunnel_builder.gd")
const ObstacleManager = preload("res://scripts/obstacles/obstacle_manager.gd")
const PlayerController = preload("res://scripts/player/player_controller.gd")
const CameraRig = preload("res://scripts/player/camera_rig.gd")
const InputHandler = preload("res://scripts/player/input_handler.gd")
const EffectsManager = preload("res://scripts/effects/effects_manager.gd")
const ScreenFx = preload("res://scripts/effects/screen_fx.gd")
const WorldEnv = preload("res://scripts/environment/world_env.gd")

var tunnel
var obstacles
var player
var camera_rig
var effects
var screen_fx
var input_handler
var environment_node: WorldEnvironment
var sun: DirectionalLight3D
var player_light: OmniLight3D

func _ready() -> void:
    environment_node = WorldEnv.build()
    add_child(environment_node)
    sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50.0, 20.0, 0.0)
    sun.light_energy = 0.45
    add_child(sun)
    tunnel = TunnelBuilder.new()
    add_child(tunnel)
    player = PlayerController.new()
    add_child(player)
    player_light = OmniLight3D.new()
    player_light.omni_range = 9.0
    player_light.light_energy = 1.6
    player_light.position = Vector3(0.0, -Config.TUNNEL_RADIUS + 2.4, 1.2)
    player.add_child(player_light)
    obstacles = ObstacleManager.new()
    add_child(obstacles)
    obstacles.setup(player)
    obstacles.hit_resolver = _resolve_hit
    camera_rig = CameraRig.new()
    add_child(camera_rig)
    camera_rig.setup(player)
    effects = EffectsManager.new()
    add_child(effects)
    effects.attach(player.runner)
    screen_fx = ScreenFx.new()
    add_child(screen_fx)
    input_handler = InputHandler.new()
    add_child(input_handler)
    input_handler.shift_requested.connect(player.request_shift)
    input_handler.jump_requested.connect(player.request_jump)
    player.shifted.connect(_on_shifted)
    player.jumped.connect(_on_jumped)
    obstacles.orb_collected.connect(_on_orb_collected)
    obstacles.powerup_collected.connect(_on_powerup_collected)
    obstacles.close_call.connect(_on_close_call)
    GameState.tier_changed.connect(_on_tier_changed)
    Settings.changed.connect(_apply_settings)
    _apply_settings()
    _apply_palette(0)
    enter_menu()

func _process(delta: float) -> void:
    match GameState.state:
        GameState.State.PLAYING:
            _step_playing(delta)
        GameState.State.MENU:
            _step_menu(delta)
        GameState.State.GAME_OVER:
            player.step(delta)
            effects.set_dust_active(false)
    camera_rig.step(delta)
    effects.step(delta)

func begin_run() -> void:
    player.reset()
    obstacles.reset()
    camera_rig.reset()
    AudioManager.set_intensity(0.0)

func enter_menu() -> void:
    GameState.go_menu()
    player.reset()
    obstacles.reset()
    camera_rig.reset()
    screen_fx.set_vignette(0.0)
    _apply_palette(0)
    AudioManager.set_intensity(0.15)

func revive() -> void:
    player.revive()
    obstacles.clear_hazards_ahead(90.0)
    camera_rig.add_shake(0.4)

func _step_playing(delta: float) -> void:
    GameState.tick(delta)
    player.step(delta)
    obstacles.step(delta)
    tunnel.step()
    player.runner.set_shield(GameState.shield)
    effects.set_dust_active(not player.airborne)
    var ratio := GameState.speed_ratio()
    AudioManager.set_intensity(ratio)
    screen_fx.set_vignette(ratio * 0.7)

func _step_menu(delta: float) -> void:
    GameState.distance += Config.START_SPEED * 0.8 * delta
    player.attract(delta)
    tunnel.step()
    effects.set_dust_active(true)

func _resolve_hit(_kind: int) -> bool:
    var had_shield := GameState.shield
    if GameState.absorb_hit():
        if had_shield:
            AudioManager.play_sfx("shield_break")
            Settings.vibrate(40)
            effects.play_shield_break(player.chest_position())
            camera_rig.add_shake(0.5)
            screen_fx.pulse(0.03)
        return true
    _crash()
    return false

func _crash() -> void:
    GameState.end_run()
    player.crash()
    effects.play_crash(player.chest_position())
    camera_rig.add_shake(1.3)
    screen_fx.pulse(0.05)
    AudioManager.play_sfx("crash")
    Settings.vibrate(280)
    await get_tree().create_timer(1.1).timeout
    crash_finished.emit()

func _on_shifted(_direction: int) -> void:
    AudioManager.play_sfx("shift")
    Settings.vibrate(18)
    screen_fx.pulse(0.022)
    camera_rig.add_shake(0.1)

func _on_jumped() -> void:
    AudioManager.play_sfx("jump")

func _on_orb_collected(at: Vector3) -> void:
    GameState.collect_orb()
    effects.play_orb(at)
    AudioManager.play_sfx("orb", 1.0 + minf(GameState.combo, 12) * 0.05)
    Settings.vibrate(10)

func _on_powerup_collected(kind: int, at: Vector3) -> void:
    GameState.activate_powerup(kind)
    effects.play_orb(at)
    AudioManager.play_sfx("powerup")
    Settings.vibrate(25)

func _on_close_call() -> void:
    GameState.register_close_call()
    camera_rig.add_shake(0.35)
    AudioManager.play_sfx("close_call")
    Settings.vibrate(15)

func _on_tier_changed(tier: int) -> void:
    _apply_palette(tier)
    if tier > 0:
        screen_fx.pulse(0.04)
        AudioManager.play_sfx("powerup")

func _apply_palette(tier: int) -> void:
    var palette := Config.palette(tier)
    Materials.apply_palette(palette)
    WorldEnv.tint(environment_node, palette)
    var line_color: Color = palette["line"]
    player_light.light_color = line_color

func _apply_settings() -> void:
    var quality: int = SaveManager.quality
    WorldEnv.apply_quality(environment_node, quality)
    get_viewport().msaa_3d = Viewport.MSAA_2X if quality == 2 else Viewport.MSAA_DISABLED
    effects.set_quality(quality)
    screen_fx.set_enabled(quality >= 1)

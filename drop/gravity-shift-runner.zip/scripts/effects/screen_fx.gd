extends CanvasLayer

var rect: ColorRect
var fx_material: ShaderMaterial
var pulse_tween: Tween

func _ready() -> void:
    layer = 1
    rect = ColorRect.new()
    rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    fx_material = ShaderMaterial.new()
    fx_material.shader = load("res://shaders/screen_fx.gdshader")
    rect.material = fx_material
    add_child(rect)
    rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func pulse(strength: float) -> void:
    if pulse_tween != null and pulse_tween.is_valid():
        pulse_tween.kill()
    fx_material.set_shader_parameter("aberration", strength)
    pulse_tween = create_tween()
    pulse_tween.tween_method(_set_aberration, strength, 0.0, 0.35)

func set_vignette(amount: float) -> void:
    fx_material.set_shader_parameter("vignette", clampf(amount, 0.0, 1.0))

func set_enabled(enabled: bool) -> void:
    rect.visible = enabled

func _set_aberration(value: float) -> void:
    fx_material.set_shader_parameter("aberration", value)

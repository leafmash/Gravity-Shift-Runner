extends Node3D

const ParticleFactory = preload("res://scripts/effects/particle_factory.gd")

var speed_lines: GPUParticles3D
var dust: GPUParticles3D
var crash_burst: GPUParticles3D
var shield_burst: GPUParticles3D
var orb_bursts: Array = []
var orb_cursor := 0
var emitters: Array = []
var amount_ratio := 0.7

func _ready() -> void:
    speed_lines = ParticleFactory.create_speed_lines()
    add_child(speed_lines)
    emitters.append(speed_lines)
    crash_burst = ParticleFactory.create_burst(Color(1.0, 0.45, 0.15), 80, 5.0, 16.0, 0.12, 1.0)
    add_child(crash_burst)
    emitters.append(crash_burst)
    shield_burst = ParticleFactory.create_burst(Color(0.3, 0.9, 1.0), 40, 3.0, 9.0, 0.08, 0.7)
    add_child(shield_burst)
    emitters.append(shield_burst)
    for index in 4:
        var burst := ParticleFactory.create_burst(Color(1.0, 0.9, 0.3), 18, 2.0, 6.0, 0.06, 0.5)
        add_child(burst)
        orb_bursts.append(burst)
        emitters.append(burst)

func attach(runner: Node3D) -> void:
    dust = ParticleFactory.create_dust()
    dust.position = Vector3(0.0, 0.05, 0.25)
    dust.emitting = false
    runner.add_child(dust)
    emitters.append(dust)
    set_quality(SaveManager.quality)

func set_quality(level: int) -> void:
    amount_ratio = 0.4 if level == 0 else (0.7 if level == 1 else 1.0)
    for emitter in emitters:
        emitter.amount_ratio = amount_ratio

func set_dust_active(active: bool) -> void:
    if dust != null and dust.emitting != active:
        dust.emitting = active

func step(_delta: float) -> void:
    speed_lines.speed_scale = 0.8 + GameState.speed_ratio()
    if dust != null:
        dust.speed_scale = clampf(GameState.speed / 14.0, 0.8, 2.2)

func play_orb(at: Vector3) -> void:
    var burst: GPUParticles3D = orb_bursts[orb_cursor]
    orb_cursor = (orb_cursor + 1) % orb_bursts.size()
    _fire(burst, at)

func play_shield_break(at: Vector3) -> void:
    _fire(shield_burst, at)

func play_crash(at: Vector3) -> void:
    _fire(crash_burst, at)

func _fire(burst: GPUParticles3D, at: Vector3) -> void:
    burst.global_position = at
    burst.restart()
    burst.emitting = true

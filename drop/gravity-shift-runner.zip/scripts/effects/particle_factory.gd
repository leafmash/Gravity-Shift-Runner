extends RefCounted

static func _fade_ramp() -> GradientTexture1D:
    var gradient := Gradient.new()
    gradient.set_color(0, Color(1.0, 1.0, 1.0, 1.0))
    gradient.set_color(1, Color(1.0, 1.0, 1.0, 0.0))
    var ramp := GradientTexture1D.new()
    ramp.gradient = gradient
    return ramp

static func _glow_mesh(color: Color, radius: float) -> SphereMesh:
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 6
    mesh.rings = 3
    var material := StandardMaterial3D.new()
    material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    material.vertex_color_use_as_albedo = true
    material.albedo_color = color
    mesh.material = material
    return mesh

static func create_burst(color: Color, amount: int, speed_min: float, speed_max: float, radius: float, lifetime: float) -> GPUParticles3D:
    var particles := GPUParticles3D.new()
    particles.amount = amount
    particles.lifetime = lifetime
    particles.one_shot = true
    particles.explosiveness = 1.0
    particles.emitting = false
    var material := ParticleProcessMaterial.new()
    material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
    material.emission_sphere_radius = 0.15
    material.direction = Vector3(0.0, 1.0, 0.0)
    material.spread = 180.0
    material.initial_velocity_min = speed_min
    material.initial_velocity_max = speed_max
    material.gravity = Vector3.ZERO
    material.damping_min = 2.0
    material.damping_max = 4.0
    material.color_ramp = _fade_ramp()
    particles.process_material = material
    particles.draw_pass_1 = _glow_mesh(color, radius)
    particles.visibility_aabb = AABB(Vector3(-14.0, -14.0, -14.0), Vector3(28.0, 28.0, 28.0))
    return particles

static func create_speed_lines() -> GPUParticles3D:
    var particles := GPUParticles3D.new()
    particles.amount = 70
    particles.lifetime = 1.3
    particles.preprocess = 1.3
    var material := ParticleProcessMaterial.new()
    material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
    material.emission_box_extents = Vector3(2.7, 2.7, 1.0)
    material.direction = Vector3(0.0, 0.0, 1.0)
    material.spread = 0.0
    material.initial_velocity_min = 60.0
    material.initial_velocity_max = 90.0
    material.gravity = Vector3.ZERO
    particles.process_material = material
    var mesh := BoxMesh.new()
    mesh.size = Vector3(0.03, 0.03, 2.2)
    var mesh_material := StandardMaterial3D.new()
    mesh_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mesh_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mesh_material.albedo_color = Color(0.6, 0.95, 1.0, 0.5)
    mesh.material = mesh_material
    particles.draw_pass_1 = mesh
    particles.visibility_aabb = AABB(Vector3(-5.0, -5.0, -90.0), Vector3(10.0, 10.0, 110.0))
    particles.position = Vector3(0.0, 0.0, -75.0)
    return particles

static func create_dust() -> GPUParticles3D:
    var particles := GPUParticles3D.new()
    particles.amount = 28
    particles.lifetime = 0.55
    var material := ParticleProcessMaterial.new()
    material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
    material.emission_sphere_radius = 0.15
    material.direction = Vector3(0.0, 0.25, 1.0)
    material.spread = 25.0
    material.initial_velocity_min = 6.0
    material.initial_velocity_max = 10.0
    material.gravity = Vector3.ZERO
    material.scale_min = 0.6
    material.scale_max = 1.2
    material.color_ramp = _fade_ramp()
    particles.process_material = material
    particles.draw_pass_1 = _glow_mesh(Color(0.7, 0.9, 1.0, 0.6), 0.07)
    particles.visibility_aabb = AABB(Vector3(-4.0, -4.0, -4.0), Vector3(8.0, 8.0, 12.0))
    return particles

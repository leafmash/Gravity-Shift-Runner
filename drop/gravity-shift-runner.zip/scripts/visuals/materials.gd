extends RefCounted

const Config = preload("res://scripts/config.gd")

static var cache := {}

static func _shader_material(key: String, path: String) -> ShaderMaterial:
    if not cache.has(key):
        var material := ShaderMaterial.new()
        material.shader = load(path)
        cache[key] = material
    return cache[key]

static func _emissive(key: String, energy: float) -> StandardMaterial3D:
    if not cache.has(key):
        var material := StandardMaterial3D.new()
        material.emission_enabled = true
        material.emission_energy_multiplier = energy
        material.roughness = 0.5
        cache[key] = material
    return cache[key]

static func wall() -> ShaderMaterial:
    return _shader_material("wall", "res://shaders/tunnel_wall.gdshader")

static func strip() -> ShaderMaterial:
    return _shader_material("strip", "res://shaders/tunnel_strip.gdshader")

static func gap() -> ShaderMaterial:
    return _shader_material("gap", "res://shaders/gap_hole.gdshader")

static func ring() -> StandardMaterial3D:
    return _emissive("ring", 1.6)

static func hazard() -> StandardMaterial3D:
    return _emissive("hazard", 2.2)

static func orb() -> StandardMaterial3D:
    return _emissive("orb", 2.6)

static func accent() -> StandardMaterial3D:
    return _emissive("accent", 2.0)

static func body() -> StandardMaterial3D:
    if not cache.has("body"):
        var material := StandardMaterial3D.new()
        material.albedo_color = Color(0.1, 0.12, 0.2)
        material.metallic = 0.4
        material.roughness = 0.45
        material.emission_enabled = true
        material.emission = Color(0.0, 0.25, 0.35)
        material.emission_energy_multiplier = 0.6
        cache["body"] = material
    return cache["body"]

static func shield_bubble() -> StandardMaterial3D:
    if not cache.has("bubble"):
        var material := StandardMaterial3D.new()
        material.albedo_color = Color(0.2, 0.85, 1.0, 0.16)
        material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        material.emission_enabled = true
        material.emission = Color(0.2, 0.8, 1.0)
        material.emission_energy_multiplier = 0.8
        material.rim_enabled = true
        material.rim = 0.8
        cache["bubble"] = material
    return cache["bubble"]

static func pickup(kind: int) -> StandardMaterial3D:
    var key := "pickup_%d" % kind
    if not cache.has(key):
        var color := Color(0.2, 0.9, 1.0)
        if kind == Config.Obstacle.SLOW:
            color = Color(0.75, 0.35, 1.0)
        elif kind == Config.Obstacle.MAGNET:
            color = Color(1.0, 0.65, 0.1)
        var material := StandardMaterial3D.new()
        material.albedo_color = color.darkened(0.6)
        material.emission_enabled = true
        material.emission = color
        material.emission_energy_multiplier = 2.6
        cache[key] = material
    return cache[key]

static func _tint(material: StandardMaterial3D, color: Color, energy: float) -> void:
    material.albedo_color = color.darkened(0.7)
    material.emission = color
    material.emission_energy_multiplier = energy

static func apply_palette(palette: Dictionary) -> void:
    var wall_color: Color = palette["wall"]
    var line_color: Color = palette["line"]
    var hazard_color: Color = palette["hazard"]
    var orb_color: Color = palette["orb"]
    wall().set_shader_parameter("base_color", wall_color)
    wall().set_shader_parameter("line_color", line_color)
    strip().set_shader_parameter("strip_color", line_color)
    gap().set_shader_parameter("border_color", hazard_color)
    _tint(ring(), line_color, 1.6)
    _tint(hazard(), hazard_color, 2.2)
    _tint(orb(), orb_color, 2.6)
    _tint(accent(), line_color, 2.0)

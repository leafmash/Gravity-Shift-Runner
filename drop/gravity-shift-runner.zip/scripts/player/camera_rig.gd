extends Node3D

const Config = preload("res://scripts/config.gd")

var camera: Camera3D
var player
var shake := 0.0

func setup(target) -> void:
    player = target
    camera = Camera3D.new()
    camera.position = Vector3(0.0, -Config.TUNNEL_RADIUS + 2.5, 5.6)
    camera.rotation_degrees = Vector3(-10.0, 0.0, 0.0)
    camera.fov = 68.0
    camera.near = 0.05
    camera.far = 260.0
    add_child(camera)
    camera.make_current()

func add_shake(amount: float) -> void:
    shake = maxf(shake, amount)

func reset() -> void:
    rotation = Vector3.ZERO
    shake = 0.0
    camera.fov = 68.0

func step(delta: float) -> void:
    rotation.z = lerp_angle(rotation.z, player.rotation.z, 1.0 - exp(-10.0 * delta))
    var target_fov := 68.0 + 22.0 * GameState.speed_ratio()
    camera.fov = lerpf(camera.fov, target_fov, 1.0 - exp(-3.0 * delta))
    shake = move_toward(shake, 0.0, delta * 2.4)
    camera.h_offset = randf_range(-1.0, 1.0) * shake * 0.3
    camera.v_offset = randf_range(-1.0, 1.0) * shake * 0.3

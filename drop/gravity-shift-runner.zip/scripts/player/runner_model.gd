extends Node3D

const Materials = preload("res://scripts/visuals/materials.gd")

var tumble_root: Node3D
var body_root: Node3D
var torso: MeshInstance3D
var head: MeshInstance3D
var arm_left: Node3D
var arm_right: Node3D
var leg_left: Node3D
var leg_right: Node3D
var shield_bubble: MeshInstance3D
var parts: Array = []
var rest_transforms := {}
var part_velocity := {}
var part_spin := {}
var run_phase := 0.0
var tumble_tween: Tween
var crash_active := false
var rng := RandomNumberGenerator.new()

func _ready() -> void:
    rng.randomize()
    tumble_root = Node3D.new()
    tumble_root.position = Vector3(0.0, 0.9, 0.0)
    add_child(tumble_root)
    body_root = Node3D.new()
    body_root.position = Vector3(0.0, -0.9, 0.0)
    tumble_root.add_child(body_root)
    torso = _box(Vector3(0.5, 0.7, 0.3), Vector3(0.0, 1.05, 0.0), Materials.body())
    body_root.add_child(torso)
    head = MeshInstance3D.new()
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.2
    head_mesh.height = 0.4
    head_mesh.radial_segments = 10
    head_mesh.rings = 5
    head.mesh = head_mesh
    head.material_override = Materials.accent()
    head.position = Vector3(0.0, 1.62, 0.0)
    body_root.add_child(head)
    arm_left = _limb(Vector3(0.34, 1.38, 0.0), Vector3(0.14, 0.6, 0.14))
    arm_right = _limb(Vector3(-0.34, 1.38, 0.0), Vector3(0.14, 0.6, 0.14))
    leg_left = _limb(Vector3(0.14, 0.72, 0.0), Vector3(0.18, 0.72, 0.18))
    leg_right = _limb(Vector3(-0.14, 0.72, 0.0), Vector3(0.18, 0.72, 0.18))
    parts = [torso, head, arm_left, arm_right, leg_left, leg_right]
    for part in parts:
        rest_transforms[part] = part.transform
    shield_bubble = MeshInstance3D.new()
    var bubble_mesh := SphereMesh.new()
    bubble_mesh.radius = 1.15
    bubble_mesh.height = 2.3
    bubble_mesh.radial_segments = 16
    bubble_mesh.rings = 8
    shield_bubble.mesh = bubble_mesh
    shield_bubble.material_override = Materials.shield_bubble()
    shield_bubble.position = Vector3(0.0, 0.9, 0.0)
    shield_bubble.visible = false
    add_child(shield_bubble)

func animate(delta: float, speed: float, airborne: bool) -> void:
    if crash_active:
        _step_crash(delta)
        return
    if airborne:
        var blend := clampf(delta * 14.0, 0.0, 1.0)
        leg_left.rotation.x = lerpf(leg_left.rotation.x, -1.0, blend)
        leg_right.rotation.x = lerpf(leg_right.rotation.x, 0.5, blend)
        arm_left.rotation.x = lerpf(arm_left.rotation.x, -2.4, blend)
        arm_right.rotation.x = lerpf(arm_right.rotation.x, -2.4, blend)
        body_root.position.y = -0.9
    else:
        run_phase += delta * (6.0 + speed * 0.28)
        var swing := sin(run_phase)
        leg_left.rotation.x = swing * 0.95
        leg_right.rotation.x = -swing * 0.95
        arm_left.rotation.x = -swing * 0.8
        arm_right.rotation.x = swing * 0.8
        body_root.position.y = -0.9 + absf(swing) * 0.07
    torso.rotation.x = -0.12
    if shield_bubble.visible:
        shield_bubble.rotation.y += delta * 1.5
        var pulse := 1.0 + sin(run_phase * 0.5 + Time.get_ticks_msec() * 0.006) * 0.04
        shield_bubble.scale = Vector3(pulse, pulse, pulse)

func tumble() -> void:
    if crash_active:
        return
    _kill_tumble()
    tumble_root.rotation = Vector3.ZERO
    tumble_tween = create_tween()
    tumble_tween.tween_property(tumble_root, "rotation:x", -TAU, 0.32).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tumble_tween.tween_callback(_clear_tumble)

func set_shield(enabled: bool) -> void:
    shield_bubble.visible = enabled

func start_crash() -> void:
    crash_active = true
    _kill_tumble()
    tumble_root.rotation = Vector3.ZERO
    for part in parts:
        part_velocity[part] = Vector3(rng.randf_range(-3.5, 3.5), rng.randf_range(3.0, 8.0), rng.randf_range(-7.0, -1.5))
        part_spin[part] = Vector3(rng.randf_range(-12.0, 12.0), rng.randf_range(-6.0, 6.0), rng.randf_range(-12.0, 12.0))
    shield_bubble.visible = false

func reset_pose() -> void:
    crash_active = false
    _kill_tumble()
    tumble_root.rotation = Vector3.ZERO
    for part in parts:
        part.transform = rest_transforms[part]

func _clear_tumble() -> void:
    tumble_root.rotation = Vector3.ZERO

func _kill_tumble() -> void:
    if tumble_tween != null and tumble_tween.is_valid():
        tumble_tween.kill()

func _step_crash(delta: float) -> void:
    for part in parts:
        var velocity: Vector3 = part_velocity[part]
        var spin: Vector3 = part_spin[part]
        velocity.y -= 22.0 * delta
        part.position += velocity * delta
        part.rotation += spin * delta
        if part.position.y < 0.12:
            part.position.y = 0.12
            velocity.y = absf(velocity.y) * 0.35
            velocity.x *= 0.7
            velocity.z *= 0.7
        part_velocity[part] = velocity

func _box(size: Vector3, offset: Vector3, material: Material) -> MeshInstance3D:
    var mesh := BoxMesh.new()
    mesh.size = size
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.position = offset
    instance.material_override = material
    return instance

func _limb(pivot_position: Vector3, size: Vector3) -> Node3D:
    var pivot := Node3D.new()
    pivot.position = pivot_position
    pivot.add_child(_box(size, Vector3(0.0, -size.y * 0.5, 0.0), Materials.accent()))
    body_root.add_child(pivot)
    return pivot

extends Node3D

const Config = preload("res://scripts/config.gd")
const RunnerModel = preload("res://scripts/player/runner_model.gd")

signal shifted(direction)
signal jumped
signal landed

var runner
var target_steps := 0
var shift_tween: Tween
var jump_height := 0.0
var jump_velocity := 0.0
var airborne := false
var crashed := false
var previous_surface := 0
var last_shift_time := -100.0
var last_shift_started := -100.0
var pending_shifts: Array = []
var pending_jump_time := -100.0

func _ready() -> void:
    runner = RunnerModel.new()
    runner.position = Vector3(0.0, -Config.TUNNEL_RADIUS, 0.0)
    add_child(runner)

func request_shift(direction: int) -> void:
    pending_shifts.append({"direction": direction, "time": _now()})
    if pending_shifts.size() > 3:
        pending_shifts.pop_front()

func request_jump() -> void:
    pending_jump_time = _now()

func current_surface() -> int:
    return posmod(roundi(rotation.z / (PI / 2.0)), 4)

func seconds_since_shift() -> float:
    return _now() - last_shift_time

func chest_position() -> Vector3:
    return runner.global_position + runner.global_transform.basis.y * 0.9

func step(delta: float) -> void:
    if crashed:
        runner.animate(delta, 0.0, false)
        return
    var now := _now()
    _process_shift_buffer(now)
    _process_jump(delta, now)
    runner.position.y = -Config.TUNNEL_RADIUS + jump_height
    runner.animate(delta, GameState.speed, airborne)

func attract(delta: float) -> void:
    rotation.z += delta * 0.45
    runner.position.y = -Config.TUNNEL_RADIUS
    runner.animate(delta, 16.0, false)

func reset() -> void:
    _kill_shift_tween()
    rotation = Vector3.ZERO
    target_steps = 0
    jump_height = 0.0
    jump_velocity = 0.0
    airborne = false
    crashed = false
    previous_surface = 0
    pending_shifts.clear()
    pending_jump_time = -100.0
    runner.reset_pose()
    runner.position = Vector3(0.0, -Config.TUNNEL_RADIUS, 0.0)

func crash() -> void:
    crashed = true
    runner.start_crash()

func revive() -> void:
    crashed = false
    jump_height = 0.0
    jump_velocity = 0.0
    airborne = false
    pending_shifts.clear()
    runner.reset_pose()
    runner.position = Vector3(0.0, -Config.TUNNEL_RADIUS, 0.0)

func _now() -> float:
    return Time.get_ticks_msec() / 1000.0

func _kill_shift_tween() -> void:
    if shift_tween != null and shift_tween.is_valid():
        shift_tween.kill()

func _process_shift_buffer(now: float) -> void:
    while not pending_shifts.is_empty():
        var entry: Dictionary = pending_shifts[0]
        if now - float(entry["time"]) > Config.SHIFT_BUFFER_TIME:
            pending_shifts.pop_front()
            continue
        if now - last_shift_started < Config.SHIFT_COOLDOWN:
            return
        pending_shifts.pop_front()
        _apply_shift(int(entry["direction"]), now)
        return

func _apply_shift(direction: int, now: float) -> void:
    previous_surface = current_surface()
    target_steps += direction
    last_shift_started = now
    last_shift_time = now
    _kill_shift_tween()
    shift_tween = create_tween()
    var target_angle := target_steps * PI / 2.0
    shift_tween.tween_property(self, "rotation:z", target_angle, Config.SHIFT_DURATION).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    runner.tumble()
    shifted.emit(direction)

func _process_jump(delta: float, now: float) -> void:
    if not airborne and now - pending_jump_time <= Config.JUMP_BUFFER_TIME:
        airborne = true
        jump_velocity = Config.JUMP_VELOCITY
        pending_jump_time = -100.0
        jumped.emit()
    if airborne:
        jump_velocity -= Config.JUMP_GRAVITY * delta
        jump_height += jump_velocity * delta
        if jump_height <= 0.0:
            jump_height = 0.0
            jump_velocity = 0.0
            airborne = false
            landed.emit()

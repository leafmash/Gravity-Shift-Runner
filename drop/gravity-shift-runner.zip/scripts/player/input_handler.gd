extends Node

signal shift_requested(direction)
signal jump_requested

const SWIPE_DISTANCE := 60.0
const HUD_BAND := 190.0

var touch_origins := {}
var swiped := {}

func _input(event: InputEvent) -> void:
    if GameState.state != GameState.State.PLAYING:
        touch_origins.clear()
        swiped.clear()
        return
    if event is InputEventScreenTouch:
        _handle_touch(event as InputEventScreenTouch)
    elif event is InputEventScreenDrag:
        _handle_drag(event as InputEventScreenDrag)
    elif event is InputEventKey:
        _handle_key(event as InputEventKey)

func _handle_touch(touch: InputEventScreenTouch) -> void:
    if touch.pressed:
        if touch.position.y < HUD_BAND:
            return
        touch_origins[touch.index] = touch.position
        swiped.erase(touch.index)
        return
    if not touch_origins.has(touch.index):
        return
    var origin: Vector2 = touch_origins[touch.index]
    touch_origins.erase(touch.index)
    if swiped.has(touch.index):
        swiped.erase(touch.index)
        return
    var half_width := get_viewport().get_visible_rect().size.x * 0.5
    shift_requested.emit(1 if origin.x < half_width else -1)

func _handle_drag(drag: InputEventScreenDrag) -> void:
    if not touch_origins.has(drag.index) or swiped.has(drag.index):
        return
    var origin: Vector2 = touch_origins[drag.index]
    var offset := drag.position - origin
    if -offset.y > SWIPE_DISTANCE and absf(offset.y) > absf(offset.x):
        swiped[drag.index] = true
        jump_requested.emit()

func _handle_key(key: InputEventKey) -> void:
    if not key.pressed or key.echo:
        return
    match key.keycode:
        KEY_A, KEY_LEFT:
            shift_requested.emit(1)
        KEY_D, KEY_RIGHT:
            shift_requested.emit(-1)
        KEY_SPACE, KEY_UP, KEY_W:
            jump_requested.emit()

extends Node3D

const Config = preload("res://scripts/config.gd")
const Materials = preload("res://scripts/visuals/materials.gd")

const RING_COUNT := 4

var segments: Array = []
var starts: Array = []

func _ready() -> void:
    var wall_mesh := _build_wall_mesh()
    var strip_mesh := _build_strip_mesh()
    var ring_multimesh := _build_ring_multimesh()
    for index in Config.SEGMENT_COUNT:
        var segment := Node3D.new()
        add_child(segment)
        segment.add_child(_instance(wall_mesh, Materials.wall()))
        segment.add_child(_instance(strip_mesh, Materials.strip()))
        var rings := MultiMeshInstance3D.new()
        rings.multimesh = ring_multimesh
        rings.material_override = Materials.ring()
        segment.add_child(rings)
        segments.append(segment)
        starts.append(float(index - 1) * Config.SEGMENT_LENGTH)

func step() -> void:
    var distance := GameState.distance
    var length := Config.SEGMENT_LENGTH
    var span := length * Config.SEGMENT_COUNT
    for index in segments.size():
        var start: float = starts[index]
        while start + length < distance - 12.0:
            start += span
        starts[index] = start
        var segment: Node3D = segments[index]
        segment.position.z = distance - start

func _instance(mesh: Mesh, material: Material) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.material_override = material
    return instance

func _build_wall_mesh() -> ArrayMesh:
    var surface_tool := SurfaceTool.new()
    var radius := Config.TUNNEL_RADIUS
    var length := Config.SEGMENT_LENGTH
    for surface in 4:
        var rotation_basis := Basis(Vector3.BACK, surface * PI / 2.0)
        var plane := PlaneMesh.new()
        plane.size = Vector2(radius * 2.0, length)
        var origin := rotation_basis * Vector3(0.0, -radius, -length / 2.0)
        surface_tool.append_from(plane, 0, Transform3D(rotation_basis, origin))
    return surface_tool.commit()

func _build_strip_mesh() -> ArrayMesh:
    var surface_tool := SurfaceTool.new()
    var radius := Config.TUNNEL_RADIUS
    var length := Config.SEGMENT_LENGTH
    for surface in 4:
        var rotation_basis := Basis(Vector3.BACK, surface * PI / 2.0)
        var corner := BoxMesh.new()
        corner.size = Vector3(0.16, 0.16, length)
        var corner_origin := rotation_basis * Vector3(radius, -radius, -length / 2.0)
        surface_tool.append_from(corner, 0, Transform3D(rotation_basis, corner_origin))
        var center := BoxMesh.new()
        center.size = Vector3(0.12, 0.03, length)
        var center_origin := rotation_basis * Vector3(0.0, -radius + 0.02, -length / 2.0)
        surface_tool.append_from(center, 0, Transform3D(rotation_basis, center_origin))
    return surface_tool.commit()

func _build_ring_multimesh() -> MultiMesh:
    var surface_tool := SurfaceTool.new()
    var radius := Config.TUNNEL_RADIUS
    var length := Config.SEGMENT_LENGTH
    for surface in 4:
        var rotation_basis := Basis(Vector3.BACK, surface * PI / 2.0)
        var bar := BoxMesh.new()
        bar.size = Vector3(radius * 2.0 + 0.16, 0.12, 0.12)
        var origin := rotation_basis * Vector3(0.0, -radius, 0.0)
        surface_tool.append_from(bar, 0, Transform3D(rotation_basis, origin))
    var multimesh := MultiMesh.new()
    multimesh.transform_format = MultiMesh.TRANSFORM_3D
    multimesh.mesh = surface_tool.commit()
    multimesh.instance_count = RING_COUNT
    for index in RING_COUNT:
        var offset := -(index + 0.5) * length / RING_COUNT
        multimesh.set_instance_transform(index, Transform3D(Basis.IDENTITY, Vector3(0.0, 0.0, offset)))
    return multimesh

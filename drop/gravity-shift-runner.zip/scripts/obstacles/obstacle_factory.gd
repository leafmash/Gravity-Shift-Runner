extends RefCounted

const Config = preload("res://scripts/config.gd")
const Materials = preload("res://scripts/visuals/materials.gd")

static func build(kind: int) -> Node3D:
    match kind:
        Config.Obstacle.BLOCK:
            return _block()
        Config.Obstacle.GAP:
            return _gap()
        Config.Obstacle.LASER:
            return _laser()
        Config.Obstacle.ROTBAR:
            return _rotbar()
        Config.Obstacle.GATE:
            return _gate()
        Config.Obstacle.ORB:
            return _orb()
    return _pickup(kind)

static func _box(size: Vector3, offset: Vector3, material: Material) -> MeshInstance3D:
    var mesh := BoxMesh.new()
    mesh.size = size
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.position = offset
    instance.material_override = material
    return instance

static func _block() -> Node3D:
    var root := Node3D.new()
    var size := Vector3(4.4, Config.BLOCK_HEIGHT, 1.8)
    root.add_child(_box(size, Vector3(0.0, Config.BLOCK_HEIGHT * 0.5, 0.0), Materials.hazard()))
    return root

static func _gap() -> Node3D:
    var root := Node3D.new()
    var mesh := PlaneMesh.new()
    mesh.size = Vector2(Config.TUNNEL_RADIUS * 2.0 - 0.2, Config.GAP_LENGTH)
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.position = Vector3(0.0, 0.04, 0.0)
    instance.material_override = Materials.gap()
    root.add_child(instance)
    return root

static func _laser() -> Node3D:
    var root := Node3D.new()
    var half := Config.TUNNEL_RADIUS - 0.2
    root.add_child(_box(Vector3(0.3, 1.6, 0.3), Vector3(-half, 0.8, 0.0), Materials.accent()))
    root.add_child(_box(Vector3(0.3, 1.6, 0.3), Vector3(half, 0.8, 0.0), Materials.accent()))
    var beam := _box(Vector3(half * 2.0, 0.14, 0.14), Vector3(0.0, Config.LASER_HEIGHT, 0.0), Materials.hazard())
    root.add_child(beam)
    root.set_meta("beam", beam)
    return root

static func _rotbar() -> Node3D:
    var root := Node3D.new()
    var pivot := Node3D.new()
    var arm_length := Config.TUNNEL_RADIUS - 0.2
    var arm_size := Vector3(arm_length, 0.35, 0.6)
    pivot.add_child(_box(arm_size, Vector3(arm_length * 0.5, 0.0, 0.0), Materials.hazard()))
    pivot.add_child(_box(arm_size, Vector3(-arm_length * 0.5, 0.0, 0.0), Materials.hazard()))
    pivot.add_child(_box(Vector3(0.7, 0.7, 0.8), Vector3.ZERO, Materials.accent()))
    root.add_child(pivot)
    root.set_meta("pivot", pivot)
    return root

static func _gate() -> Node3D:
    var root := Node3D.new()
    var slabs: Array = []
    for surface in 4:
        var rotation_basis := Basis(Vector3.BACK, surface * PI / 2.0)
        var slab := _box(Vector3(Config.TUNNEL_RADIUS * 2.0, Config.GATE_HEIGHT, 0.7), Vector3.ZERO, Materials.hazard())
        var origin := rotation_basis * Vector3(0.0, -Config.TUNNEL_RADIUS + Config.GATE_HEIGHT * 0.5, 0.0)
        slab.transform = Transform3D(rotation_basis, origin)
        root.add_child(slab)
        slabs.append(slab)
    root.set_meta("slabs", slabs)
    return root

static func _orb() -> Node3D:
    var root := Node3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.28
    mesh.height = 0.56
    mesh.radial_segments = 10
    mesh.rings = 5
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.position = Vector3(0.0, 0.9, 0.0)
    instance.material_override = Materials.orb()
    root.add_child(instance)
    return root

static func _pickup(kind: int) -> Node3D:
    var root := Node3D.new()
    var instance := MeshInstance3D.new()
    if kind == Config.Obstacle.SHIELD:
        var sphere := SphereMesh.new()
        sphere.radius = 0.38
        sphere.height = 0.76
        sphere.radial_segments = 12
        sphere.rings = 6
        instance.mesh = sphere
    elif kind == Config.Obstacle.SLOW:
        var cube := BoxMesh.new()
        cube.size = Vector3(0.55, 0.55, 0.55)
        instance.mesh = cube
        instance.rotation = Vector3(0.7, 0.0, 0.7)
    else:
        var torus := TorusMesh.new()
        torus.inner_radius = 0.14
        torus.outer_radius = 0.4
        instance.mesh = torus
        instance.rotation = Vector3(PI / 2.0, 0.0, 0.0)
    instance.position = Vector3(0.0, 1.0, 0.0)
    instance.material_override = Materials.pickup(kind)
    root.add_child(instance)
    return root

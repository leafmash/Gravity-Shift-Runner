extends Node3D

const Config = preload("res://scripts/config.gd")
const ObstaclePool = preload("res://scripts/obstacles/obstacle_pool.gd")
const PatternGenerator = preload("res://scripts/obstacles/pattern_generator.gd")

signal orb_collected(at)
signal powerup_collected(kind, at)
signal close_call

var pool
var generator
var player
var hit_resolver: Callable
var active: Array = []
var next_row_distance := 0.0
var elapsed := 0.0

func _ready() -> void:
    pool = ObstaclePool.new()
    add_child(pool)
    generator = PatternGenerator.new()

func setup(target) -> void:
    player = target
    reset()

func reset() -> void:
    for record in active:
        pool.release(record["node"], record["type"])
    active.clear()
    generator.reset(0)
    next_row_distance = GameState.distance + 70.0

func clear_hazards_ahead(range_meters: float) -> void:
    var distance := GameState.distance
    for index in range(active.size() - 1, -1, -1):
        var record: Dictionary = active[index]
        var ahead := float(record["distance"]) - distance
        if int(record["type"]) < Config.Obstacle.ORB and ahead < range_meters and ahead > -5.0:
            _remove(index)

func step(delta: float) -> void:
    elapsed += delta * GameState.time_factor()
    if not GameState.tutorial_active:
        _spawn_ahead()
    var distance := GameState.distance
    var surface: int = player.current_surface()
    var jump: float = player.jump_height
    var magnet := GameState.magnet_left > 0.0
    for index in range(active.size() - 1, -1, -1):
        var record: Dictionary = active[index]
        if _update_record(record, distance, surface, jump, magnet, delta):
            _remove(index)

func _spawn_ahead() -> void:
    next_row_distance = maxf(next_row_distance, GameState.distance + 60.0)
    var horizon := GameState.distance + Config.SPAWN_DISTANCE
    while next_row_distance < horizon:
        var specs: Array = generator.generate_row(GameState.tier, GameState.speed)
        for spec in specs:
            _spawn(spec, next_row_distance)
        next_row_distance += generator.last_spacing

func _spawn(spec: Dictionary, row_distance: float) -> void:
    var kind: int = spec["type"]
    var node: Node3D = pool.acquire(kind)
    var surface: int = spec.get("surface", 0)
    var open_surface: int = spec.get("open", 0)
    var record := {
        "node": node,
        "type": kind,
        "surface": surface,
        "distance": row_distance + float(spec.get("offset", 0.0)),
        "phase": float(spec.get("phase", 0.0)),
        "direction": float(spec.get("direction", 1.0)),
        "open": open_surface,
        "pulled": false,
        "done": false,
        "passed": false,
    }
    _place(node, kind, surface, open_surface)
    active.append(record)

func _place(node: Node3D, kind: int, surface: int, open_surface: int) -> void:
    if kind == Config.Obstacle.ROTBAR or kind == Config.Obstacle.GATE:
        node.transform = Transform3D.IDENTITY
        if kind == Config.Obstacle.GATE:
            pool.configure_gate(node, open_surface)
        return
    var rotation_basis := Basis(Vector3.BACK, surface * PI / 2.0)
    var origin := rotation_basis * Vector3(0.0, -Config.TUNNEL_RADIUS, 0.0)
    node.transform = Transform3D(rotation_basis, origin)

func _remove(index: int) -> void:
    var record: Dictionary = active[index]
    pool.release(record["node"], record["type"])
    active.remove_at(index)

func _update_record(record: Dictionary, distance: float, surface: int, jump: float, magnet: bool, delta: float) -> bool:
    var node: Node3D = record["node"]
    var kind: int = record["type"]
    var z := -(float(record["distance"]) - distance)
    if z > Config.DESPAWN_DISTANCE:
        return true
    if kind >= Config.Obstacle.ORB:
        return _update_collectible(record, node, kind, z, surface, magnet, delta)
    node.position.z = z
    if kind == Config.Obstacle.LASER:
        var beam: Node3D = node.get_meta("beam")
        beam.visible = _laser_on(record)
    elif kind == Config.Obstacle.ROTBAR:
        var pivot: Node3D = node.get_meta("pivot")
        pivot.rotation.z = _bar_angle(record)
    if record["done"]:
        return false
    if not record["passed"] and z > 0.6:
        record["passed"] = true
        _check_close_call(record)
    if _is_hit(record, kind, z, surface, jump):
        record["done"] = true
        var absorbed: bool = hit_resolver.call(kind)
        if absorbed:
            node.visible = false
    return false

func _update_collectible(record: Dictionary, node: Node3D, kind: int, z: float, surface: int, magnet: bool, delta: float) -> bool:
    node.rotate_y(delta * 2.5)
    if record["pulled"]:
        var target: Vector3 = player.chest_position()
        node.global_position = node.global_position.lerp(target, clampf(delta * 11.0, 0.0, 1.0))
        if node.global_position.distance_to(target) < 0.9:
            _collect(kind, node)
            return true
        return false
    node.position.z = z
    if magnet and kind == Config.Obstacle.ORB and z > -16.0 and z < 1.5:
        record["pulled"] = true
        return false
    if absf(z) < 1.1 and int(record["surface"]) == surface:
        _collect(kind, node)
        return true
    return false

func _collect(kind: int, node: Node3D) -> void:
    if kind == Config.Obstacle.ORB:
        orb_collected.emit(node.global_position)
    else:
        powerup_collected.emit(kind, node.global_position)

func _laser_on(record: Dictionary) -> bool:
    var cycle := fposmod(elapsed + float(record["phase"]), Config.LASER_PERIOD)
    return cycle < Config.LASER_PERIOD * Config.LASER_ON_RATIO

func _bar_angle(record: Dictionary) -> float:
    return float(record["phase"]) * TAU + float(record["direction"]) * Config.ROTBAR_SPEED * elapsed

func _bar_hits_player(record: Dictionary) -> bool:
    var down_angle: float = player.rotation.z - PI / 2.0
    var difference := fposmod(_bar_angle(record) - down_angle, PI)
    return minf(difference, PI - difference) < 0.42

func _is_hit(record: Dictionary, kind: int, z: float, surface: int, jump: float) -> bool:
    var record_surface: int = record["surface"]
    match kind:
        Config.Obstacle.BLOCK:
            return record_surface == surface and absf(z) < 1.3 and jump < Config.SAFE_JUMP_HEIGHT
        Config.Obstacle.GAP:
            return record_surface == surface and absf(z) < Config.GAP_LENGTH * 0.5 - 0.1 and jump < 0.15
        Config.Obstacle.LASER:
            return record_surface == surface and absf(z) < 0.3 and jump < Config.SAFE_JUMP_HEIGHT and _laser_on(record)
        Config.Obstacle.ROTBAR:
            return absf(z) < 0.45 and _bar_hits_player(record)
        Config.Obstacle.GATE:
            return absf(z) < 0.5 and surface != int(record["open"])
    return false

func _check_close_call(record: Dictionary) -> void:
    if player.seconds_since_shift() > 0.55:
        return
    var kind: int = record["type"]
    var previous: int = player.previous_surface
    var blocked := false
    match kind:
        Config.Obstacle.BLOCK, Config.Obstacle.GAP, Config.Obstacle.LASER:
            blocked = int(record["surface"]) == previous
        Config.Obstacle.GATE:
            blocked = int(record["open"]) != previous
    if blocked and player.current_surface() != previous:
        close_call.emit()

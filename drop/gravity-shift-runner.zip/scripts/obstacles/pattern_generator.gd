extends RefCounted

const Config = preload("res://scripts/config.gd")

var rng := RandomNumberGenerator.new()
var current_safe := 0
var last_spacing := 30.0

func _init() -> void:
    rng.randomize()

func reset(start_surface: int) -> void:
    current_safe = start_surface
    last_spacing = 30.0

func hazard_kinds(tier: int) -> Array:
    var kinds: Array = [Config.Obstacle.BLOCK]
    if tier >= 1:
        kinds.append(Config.Obstacle.GAP)
    if tier >= 2:
        kinds.append(Config.Obstacle.LASER)
    return kinds

func generate_row(tier: int, speed: float) -> Array:
    var specs: Array = []
    var spacing := maxf(24.0, speed)
    var roll := rng.randf()
    if tier >= 4 and roll < 0.2:
        var direction := 1.0 if rng.randf() < 0.5 else -1.0
        specs.append({"type": Config.Obstacle.ROTBAR, "phase": rng.randf(), "direction": direction})
        _append_orbs(specs, current_safe)
        last_spacing = spacing + 12.0
        return specs
    var safe := posmod(current_safe + rng.randi_range(-1, 1), 4)
    current_safe = safe
    if tier >= 3 and roll < 0.45:
        specs.append({"type": Config.Obstacle.GATE, "open": safe})
        _append_orbs(specs, safe)
        last_spacing = spacing + 6.0
        return specs
    var blocked: Array = [0, 1, 2, 3]
    blocked.erase(safe)
    blocked.shuffle()
    var count := mini(1 + int(tier / 2.0), 3)
    var kinds := hazard_kinds(tier)
    for index in count:
        var kind: int = kinds[rng.randi() % kinds.size()]
        specs.append({"type": kind, "surface": blocked[index], "phase": rng.randf() * Config.LASER_PERIOD})
    _append_orbs(specs, safe)
    if rng.randf() < 0.12:
        specs.append({"type": _random_powerup(), "surface": safe, "offset": -9.0})
    last_spacing = spacing + rng.randf_range(0.0, 8.0)
    return specs

func _append_orbs(specs: Array, surface: int) -> void:
    if rng.randf() > 0.8:
        return
    for index in 5:
        specs.append({"type": Config.Obstacle.ORB, "surface": surface, "offset": (index - 2) * 2.4})

func _random_powerup() -> int:
    var kinds: Array = [Config.Obstacle.SHIELD, Config.Obstacle.SLOW, Config.Obstacle.MAGNET]
    return kinds[rng.randi() % kinds.size()]

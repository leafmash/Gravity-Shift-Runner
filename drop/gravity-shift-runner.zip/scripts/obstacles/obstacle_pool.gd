extends Node3D

const Config = preload("res://scripts/config.gd")
const ObstacleFactory = preload("res://scripts/obstacles/obstacle_factory.gd")

var free_nodes := {}

func _ready() -> void:
    var prewarm := {
        Config.Obstacle.BLOCK: 12,
        Config.Obstacle.GAP: 8,
        Config.Obstacle.LASER: 6,
        Config.Obstacle.ROTBAR: 4,
        Config.Obstacle.GATE: 4,
        Config.Obstacle.ORB: 64,
        Config.Obstacle.SHIELD: 3,
        Config.Obstacle.SLOW: 3,
        Config.Obstacle.MAGNET: 3,
    }
    for kind in prewarm:
        var list: Array = []
        for index in int(prewarm[kind]):
            var node := ObstacleFactory.build(kind)
            node.visible = false
            add_child(node)
            list.append(node)
        free_nodes[kind] = list

func acquire(kind: int) -> Node3D:
    var list: Array = free_nodes[kind]
    var node: Node3D
    if list.is_empty():
        node = ObstacleFactory.build(kind)
        add_child(node)
    else:
        node = list.pop_back()
    node.visible = true
    return node

func release(node: Node3D, kind: int) -> void:
    node.visible = false
    var list: Array = free_nodes[kind]
    list.append(node)

func configure_gate(node: Node3D, open_surface: int) -> void:
    var slabs: Array = node.get_meta("slabs")
    for index in slabs.size():
        var slab: Node3D = slabs[index]
        slab.visible = index != open_surface

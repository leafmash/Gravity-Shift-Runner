extends RefCounted

static func build() -> WorldEnvironment:
    var environment := Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color(0.01, 0.01, 0.03)
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.3, 0.33, 0.5)
    environment.ambient_light_energy = 0.7
    environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    environment.tonemap_exposure = 1.0
    environment.glow_enabled = true
    environment.glow_intensity = 0.9
    environment.glow_strength = 1.0
    environment.glow_bloom = 0.08
    environment.glow_hdr_threshold = 0.9
    environment.glow_blend_mode = Environment.GLOW_BLEND_MODE_ADDITIVE
    environment.fog_enabled = true
    environment.fog_light_color = Color(0.01, 0.03, 0.08)
    environment.fog_density = 0.012
    var node := WorldEnvironment.new()
    node.environment = environment
    return node

static func apply_quality(node: WorldEnvironment, quality: int) -> void:
    var environment := node.environment
    environment.glow_enabled = quality >= 1
    environment.glow_intensity = 0.7 if quality == 1 else 1.1

static func tint(node: WorldEnvironment, palette: Dictionary) -> void:
    var fog_color: Color = palette["fog"]
    node.environment.fog_light_color = fog_color
    node.environment.background_color = fog_color.darkened(0.5)

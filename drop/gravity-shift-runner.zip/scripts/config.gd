extends RefCounted

enum Obstacle { BLOCK, GAP, LASER, ROTBAR, GATE, ORB, SHIELD, SLOW, MAGNET }

const TUNNEL_RADIUS := 3.0
const SEGMENT_LENGTH := 40.0
const SEGMENT_COUNT := 6
const SPAWN_DISTANCE := 200.0
const DESPAWN_DISTANCE := 12.0

const START_SPEED := 14.0
const MAX_SPEED := 32.0
const SPEED_RAMP := 0.18

const SHIFT_DURATION := 0.28
const SHIFT_COOLDOWN := 0.08
const SHIFT_BUFFER_TIME := 0.3
const JUMP_BUFFER_TIME := 0.15
const JUMP_VELOCITY := 9.5
const JUMP_GRAVITY := 28.0

const TIER_SCORE := 500
const ORB_SCORE := 25
const CLOSE_CALL_SCORE := 50
const MAX_MULTIPLIER := 8
const COMBO_WINDOW := 4.0
const SLOW_DURATION := 5.0
const MAGNET_DURATION := 8.0
const SLOW_FACTOR := 0.55
const TUTORIAL_FACTOR := 0.45
const REVIVE_COST := 25

const BLOCK_HEIGHT := 1.2
const LASER_HEIGHT := 0.7
const GATE_HEIGHT := 2.2
const GAP_LENGTH := 4.0
const SAFE_JUMP_HEIGHT := 0.95
const ROTBAR_SPEED := 1.3
const LASER_PERIOD := 1.6
const LASER_ON_RATIO := 0.55

const PALETTES := [
    {
        "wall": Color(0.015, 0.02, 0.05),
        "line": Color(0.0, 0.8, 1.0),
        "hazard": Color(1.0, 0.15, 0.35),
        "orb": Color(1.0, 0.9, 0.2),
        "fog": Color(0.01, 0.03, 0.08),
    },
    {
        "wall": Color(0.04, 0.01, 0.05),
        "line": Color(1.0, 0.2, 0.8),
        "hazard": Color(1.0, 0.7, 0.1),
        "orb": Color(0.3, 1.0, 0.9),
        "fog": Color(0.06, 0.01, 0.06),
    },
    {
        "wall": Color(0.01, 0.04, 0.02),
        "line": Color(0.2, 1.0, 0.4),
        "hazard": Color(1.0, 0.2, 0.2),
        "orb": Color(1.0, 0.9, 0.3),
        "fog": Color(0.01, 0.05, 0.03),
    },
    {
        "wall": Color(0.05, 0.025, 0.01),
        "line": Color(1.0, 0.5, 0.1),
        "hazard": Color(0.3, 0.6, 1.0),
        "orb": Color(0.9, 1.0, 0.4),
        "fog": Color(0.06, 0.03, 0.01),
    },
    {
        "wall": Color(0.025, 0.01, 0.06),
        "line": Color(0.6, 0.3, 1.0),
        "hazard": Color(1.0, 0.3, 0.5),
        "orb": Color(0.3, 1.0, 1.0),
        "fog": Color(0.03, 0.01, 0.07),
    },
    {
        "wall": Color(0.05, 0.01, 0.015),
        "line": Color(1.0, 0.15, 0.2),
        "hazard": Color(0.2, 0.9, 1.0),
        "orb": Color(1.0, 1.0, 0.3),
        "fog": Color(0.07, 0.01, 0.02),
    },
]

static func palette(tier: int) -> Dictionary:
    return PALETTES[tier % PALETTES.size()]

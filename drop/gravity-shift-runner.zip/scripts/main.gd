extends Node

const Config = preload("res://scripts/config.gd")

@onready var world = $GameWorld
@onready var ui = $UiRoot

var last_new_best := false

func _ready() -> void:
    get_tree().set_auto_accept_quit(false)
    ui.play_requested.connect(_start_run)
    ui.restart_requested.connect(_start_run)
    ui.pause_requested.connect(_pause)
    ui.resume_requested.connect(_resume)
    ui.home_requested.connect(_go_home)
    ui.revive_requested.connect(_revive)
    ui.tutorial_finished.connect(_on_tutorial_finished)
    world.crash_finished.connect(_on_crash_finished)
    world.input_handler.shift_requested.connect(ui.tutorial.on_shift)
    world.input_handler.jump_requested.connect(ui.tutorial.on_jump)
    GameState.run_ended.connect(_on_run_ended)
    ui.show_main_menu()

func _notification(what: int) -> void:
    match what:
        NOTIFICATION_WM_GO_BACK_REQUEST:
            _handle_back()
        NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_WM_WINDOW_FOCUS_OUT:
            if GameState.state == GameState.State.PLAYING:
                _pause()
            SaveManager.save_data()
        NOTIFICATION_WM_CLOSE_REQUEST:
            SaveManager.save_data()
            get_tree().quit()

func _handle_back() -> void:
    match GameState.state:
        GameState.State.PLAYING:
            _pause()
        GameState.State.PAUSED:
            _resume()
        GameState.State.GAME_OVER:
            _go_home()
        GameState.State.MENU:
            SaveManager.save_data()
            get_tree().quit()

func _start_run() -> void:
    get_tree().paused = false
    GameState.start_run()
    world.begin_run()
    ui.show_hud()
    if GameState.tutorial_active:
        ui.begin_tutorial()

func _pause() -> void:
    if GameState.state != GameState.State.PLAYING:
        return
    GameState.pause()
    get_tree().paused = true
    ui.show_pause()

func _resume() -> void:
    if GameState.state != GameState.State.PAUSED:
        return
    get_tree().paused = false
    GameState.resume()
    ui.hide_pause()

func _go_home() -> void:
    get_tree().paused = false
    world.enter_menu()
    ui.show_main_menu()

func _revive() -> void:
    if GameState.revive():
        world.revive()
        ui.show_hud()

func _on_tutorial_finished() -> void:
    GameState.finish_tutorial()

func _on_run_ended(_score: int, _best: int, _orbs: int, new_best: bool) -> void:
    last_new_best = new_best

func _on_crash_finished() -> void:
    ui.show_game_over(int(GameState.score), SaveManager.high_score, GameState.run_orbs, GameState.can_revive(), Config.REVIVE_COST, last_new_best)
